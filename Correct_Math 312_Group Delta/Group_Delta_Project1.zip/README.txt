Project 1


Each file name corresponds to a specific equation and start and end values matching the project

Submissions1 filenames correspond to using Heun's method 
Submissions2 filenames correspond to using the half-step method

v1 (or no version listed in the filename) corresponds to the function dy/dx = x - y (mathmatica file currently uses x + y)
v2 corresponds to dy/dx = ((y * log(y)) / x)
v3 corresponds to dy/dx = cuberoot((x^2)+(y^2)+1)

For example:
Submissions1_v2 is Heun's method with the function dy/dx = ((y * log(y)) / x)

These files were modified from example code 2 from chatGPTs Euler's method. Each script prints out 10 subintervals and defines the starting and ending points in main. The subintervals can be modified by changing the n variable in main. Right now, the starting and ending points match with the project's but can be changed in main. The functions are currently hard coded into the f(x,y) method but can be changed if necessary. 

Running these python files are the same

python (filename).py

Contributors: 
Lyndda, Daniel, Katherine, Gabe, Bruno, Benny